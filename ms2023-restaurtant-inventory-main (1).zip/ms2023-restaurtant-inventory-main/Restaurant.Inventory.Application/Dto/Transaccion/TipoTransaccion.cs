﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Inventory.Application.Dto.Transaccion
{
    public enum TipoTransaccion
    {
        Ingreso = 0,
        Salida = 1
    }
}
